<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<h1 align="center"> GIFTED-MD VERSION 5.0.0  </h1>
<h1 align="center"> ғᴜʟʟʏ ʙᴜᴛᴛᴏɴᴇᴅ </h1>
<p align="center"> 
  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

  <p align="center">
<a href="https://github.com/mouricedevs"><img title="GITHUB" src="https://img.shields.io/badge/GITHUB-GIFTED TECH-red.svg?style=for-the-badge&logo=github"></a>
<p/>
<p align="center">
<a href="https://github.com/mouricedevs?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/mouricedevs?label=Followers&style=social"></a>
<a href="https://github.com/mouricedevs/gifted-md/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/mouricedevs/gifted-md?&style=social"></a>
<a href="https://github.com/mouricedevs/gifted-md/network/members"><img title="Forks" src="https://img.shields.io/github/forks/mouricedevs/gifted-md?style=social"></a>
<a href="https://github.com/mouricedevs/gifted-md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/mouricedevs/gifted-md?label=Watching&style=social"></a>
  
## SETUP:

**👇FORK REPO(A MUST)**
<details>
<summary>𝗖𝗟𝗜𝗖𝗞 𝗛𝗘𝗥𝗘</summary>
  
- This is essential for you to obtain an editable repo to **[upload](https://github.com/mouricedevs/Gifted-Md/tree/main/session)** your creds.json file

<a href="https://github.com/mouricedevs/gifted-md/fork"><img src="https://img.shields.io/badge/CLICK%20HERE-purple" alt="FORK GIFTED-MD" width="150"></a>
</details>

### LINK WITH WHATSAPP

<details>
<summary>GET YOUR SESSION_ID</summary>
<a href="https://web.giftedtechnexus.co.ke/bots/giftedmd/sessions/"><img src="https://img.shields.io/badge/CLICK%20HERE-green" alt="Pairing Code" width="150"></a>

- Session ID must start with **Gifted~** and is 15 characters in length.
</details>

**OR**

<details>
<summary>GET YOUR CREDS.JSON FILE</summary>

<a href="https://web.giftedtechnexus.co.ke/bots/giftedmd/sessions/"><img src="https://img.shields.io/badge/CLICK%20HERE-blue" alt="Pairing Code" width="150"></a>

</details>

- Then **[Upload](https://github.com/mouricedevs/Gifted-Md/tree/main/session)** your creds.json file in the **[session folder](https://github.com/mouricedevs/Gifted-Md/tree/main/session)**

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### DEPLOYMENT SECTION:
**(A) HEROKU DEPLOYMENT**
<details>
<summary>CREDS.JSON DEPLOY</summary>
  
- After you've **[uploaded your creds.json](https://github.com/mouricedevs/Gifted-Md/tree/main/session)** copy paste the url below by replacing your username with ***"mouricedevs"*** then open it in your browser where you're logged in to heroku, set variables as you wish then deploy:
  
  ```
  https://dashboard.heroku.com/new?template=https://github.com/mouricedevs/Gifted-Md
  ```
</details>

<details>
<summary>SESSION_ID DEPLOY</summary>
<a href="https://web.giftedtechnexus.co.ke/deploy/platforms/heroku"><img src="https://img.shields.io/badge/CLICK%20HERE-red" alt="Pairing Code" width="150"></a>
</details>

  
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

**(B) RENDER DEPLOYMENT**
<details>
<summary>CLICK FOR MORE</summary>
<a href="https://dashboard.render.com/signup"><img src="https://img.shields.io/badge/RENDER%20SIGNUP-green" alt="Render" width="150"></a>

<a href="https://youtu.be/TVu8CQPPliM?feature=shared"><img src="https://img.shields.io/badge/WATCH%20TUTORIAL-red" alt="Render Tutorial" width="150"></a>
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

**(C) GITHUB DEPLOYMENT**
<details>
<summary>CLICK FOR MORE</summary>
<a href="https://youtu.be/0JiVJy7AzwI?feature=shared"><img src="https://img.shields.io/badge/WATCH%20TUTORIAL-yellow" alt="Github Tutorial" width="150"></a>
</details>

### EVERYTHING HASN'T BEEN UPLOADED YET SO KEEP CALM

**👇CREDITS:**
<details>
<summary>𝗖𝗟𝗜𝗖𝗞 𝗛𝗘𝗥𝗘</summary>
  
- MH MODS OFC
- ETHIX-XSID
- BOT USERS
- MYSELF
</details>

**👇FOR UPDATES:**

<details>
<summary>𝗖𝗟𝗜𝗖𝗞 𝗛𝗘𝗥𝗘</summary>
  
- **[CONTACT SUPPORT](https://t.me/mouricedevs) For More Info**
- Join [WHATSAPP CHANNEL](https://whatsapp.com/channel/0029VaYauR9ISTkHTj4xvi1l) for Daily Updates.
- **Check out my [TELEGRAM BOT MD](https://web.giftedtechnexus.co.ke/bots/tg-bot) Project.**
</details>
